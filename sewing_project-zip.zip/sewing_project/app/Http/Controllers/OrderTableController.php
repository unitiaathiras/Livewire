<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrderTableController extends Controller
{
   public function home(){
    return 'hi';
   }
        
    }
